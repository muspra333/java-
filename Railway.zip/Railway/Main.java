package Railway;

import Railway.service.RailwayTicketBookingService;
import Railway.service.RailwayTicketBookingServiceImpl;

public class Main {
    public static void main(String[] args) {
        RailwayTicketBookingService command = new RailwayTicketBookingServiceImpl();
        command.execute();
    }
}
