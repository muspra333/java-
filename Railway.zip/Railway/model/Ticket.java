package Railway.model;

import java.util.ArrayList;
import java.util.List;

public class Ticket {
    private static int current = 0;
    private int PNR;
    public int noOfSeats;
    public List<Integer> seats;
    public String bookingStatus;
    public char src, dest;
    public List<Integer> cancelledSeats = new ArrayList<>();

    public Ticket(int noOfSeats, char src, char dest) {
        current++;
        this.PNR = current;
        this.noOfSeats = noOfSeats;
        this.src = src;
        this.dest = dest;
    }

    public int getPNR() {
        return this.PNR;
    }

    public void setSeats(int start, int end) {
        int p = 0;
        for (int i = start; i < end; i++) {
            seats.add(i);
        }
    }

    public void setCancelledSeats(int noOfSeats) {
        for (int i = 0; i < noOfSeats; i++) {
            this.cancelledSeats.add(seats.get(i));
        }
        List<Integer> temp = new ArrayList<>();
        int size = seats.size();
        for (int i = noOfSeats; i < size; i++) {
            temp.add(seats.get(i));
        }
        this.seats = new ArrayList<>(temp);
    }
}
