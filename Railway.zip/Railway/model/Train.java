package Railway.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class Train {
    public static char src = 'A', dest = 'E';
    public static int totalStation = dest - src;
    public static final int totalSeats = 8, totalWL = 2;
    public static int currentWLAvail = totalWL;
    private static int[] currentSeatAvail = IntStream.generate(() -> {
        return totalSeats;
    }).limit(totalStation).toArray();
    private static int[][] seatings = new int[totalStation][totalSeats];

    public void printTrain() {
        for (int num : currentSeatAvail) {
            System.out.print(num + " ");
        }
    }

    public Train() {
        for (int i = 0; i < totalStation; i++) {
            for (int j = 0; j < totalSeats; j++) {
                seatings[i][j] = j + 1;
            }
            System.out.println(Arrays.toString(seatings[i]));
        }
    }

    public boolean isAvailable(int noOfTickets, char source, char destintation) {
        for (int i = source - src; i < destintation - src; i++) {
            if (currentSeatAvail[i] < noOfTickets) {
                return false;
            }
        }
        return true;
    }

    public void setAvailability(int noOfTickets, char source, char destination) {
        for (int i = source - src; i < destination - src; i++) {
            currentSeatAvail[i] -= noOfTickets;
        }
    }

    public void bookSeatings(Ticket ticket, int noOfTickets, char source, char destination) {
        List<Integer> seats = new ArrayList<>();
        int p = 0;
        for (int seat = 0; seat < totalSeats; seat++) {
            boolean isThisAvail = true;
            for (int station = source - src; station < destination - src; station++) {
                if (seatings[station][seat] == -1) {
                    isThisAvail = false;
                }
            }
            if (isThisAvail) {
                seats.add(seat + 1);
                p += 1;
                for (int station = source - src; station < destination - src; station++) {
                    seatings[station][seat] = -1;
                }
            }
            if (p == noOfTickets) {
                break;
            }
        }
        ticket.seats = seats;
    }

    public void updateAvailables(Ticket ticket, int noOfTickets) {
        int source = ticket.src - src, destination = ticket.dest - src;
        for (int i = source; i < destination; i++) {
            currentSeatAvail[i] += noOfTickets;
        }
        for (int i = source; i < destination; i++) {
            for (int seat : ticket.cancelledSeats) {
                seatings[i][seat - 1] = seat;
            }
        }
    }

    public void printChart() {
        System.out.println(totalStation);
        System.out.print("      ");
        for (int i = 0; i <= totalStation; i++) {
            System.out.print(" " + ((char) (src + i)) + " ");
        }
        System.out.println();
        for (int seat = 0; seat < totalSeats; seat++) {
            System.out.print(seat + 1 + "     ");
            for (int station = 0; station < totalStation; station++) {
                if (seatings[station][seat] == -1) {
                    System.out.print(" * ");
                } else {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }
    }
}
