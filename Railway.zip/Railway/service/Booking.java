package Railway.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Railway.model.Ticket;
import Railway.model.Train;

public class Booking {
    List<Ticket> waitingList = new ArrayList<>();
    Map<Integer, Ticket> bookedTickets = new HashMap<>();
    Train train = new Train();

    public void printTicket(Ticket ticket) {
        System.out.println("PNR : " + ticket.getPNR());
        System.out.println("no of seats : " + ticket.noOfSeats);
        System.out.println("seats : " + ticket.seats);
        System.out.println(ticket.bookingStatus);
        System.out.println("Source : " + ticket.src + " destination : " + ticket.dest);
        if (ticket.cancelledSeats.size() > 0) {
            System.out.println("Cancelled seats : " + ticket.cancelledSeats);
        }
    }

    public boolean isTicketBookable(int noOfTickets) {
        if (noOfTickets > Train.totalSeats) {
            System.out.println("Cannot book more than the total train seats");
            return false;
        }
        return true;
    }

    public boolean canBeBook(int noOfTickets, char src, char dest) {
        if (train.isAvailable(noOfTickets, src, dest)) {
            return true;
        }
        return false;
    }

    public void bookTicket(int noOfTickets, char src, char dest, Ticket ticket) {
        if (ticket == null) {
            ticket = new Ticket(noOfTickets, src, dest);
        }
        ticket.bookingStatus = "Booked";
        train.setAvailability(noOfTickets, src, dest);
        train.bookSeatings(ticket, noOfTickets, src, dest);
        bookedTickets.put(ticket.getPNR(), ticket);
        printTicket(ticket);
        System.out.println("Booking Successful");
    }

    // params - s[] -> 1 -> src, 2 -> dest, 3 -> no.of.tickets
    public boolean book(String[] details, Ticket t) {
        train.printTrain();
        if (details.length != 4) {
            System.out.println("Invalid Input");
            return false;
        }
        char src = details[1].charAt(0), dest = details[2].charAt(0);
        int noOfTickets = Integer.parseInt(details[3]);
        if (isTicketBookable(noOfTickets)) {
            if (canBeBook(noOfTickets, src, dest)) {
                bookTicket(noOfTickets, src, dest, t);
                return true;
            } else if (Train.currentWLAvail > 0 && Train.currentWLAvail >= noOfTickets) {
                Ticket ticket = new Ticket(noOfTickets, src, dest);
                waitingList.add(ticket);
                ticket.bookingStatus = "Waiting List";
                System.out.println("You ticket is on waiting list");
                printTicket(ticket);
                Train.currentWLAvail -= noOfTickets;
            } else {
                System.out.println("Ticket cannot be booked due to enormous amount of booking");
            }
        }
        return false;
    }

    // params - s[] -> 1 -> pnr, 2 -> no.of.tickets
    public void cancel(String[] s) {
        int pnr = Integer.parseInt(s[1]), noofTickets = Integer.parseInt(s[2]);
        Ticket ticket = bookedTickets.getOrDefault(pnr, null);
        if (ticket == null) {
            for (Ticket t : waitingList) {
                if (t.getPNR() == pnr) {
                    t.noOfSeats -= noofTickets;
                    if (t.noOfSeats <= 0) {
                        waitingList.remove(t);
                    }
                }
            }
        } else {
            ticket.noOfSeats -= noofTickets;
            if (ticket.noOfSeats == 0) {
                bookedTickets.remove(pnr);
            }
            ticket.setCancelledSeats(noofTickets);
            train.updateAvailables(ticket, noofTickets);
            printTicket(ticket);
        }
        for (Ticket t : waitingList) {
            String[] temp = { "book", t.src + "", t.dest + "", t.noOfSeats + "" };
            book(temp, t);
        }
        if (waitingList.size() > 0 && waitingList.get(0).bookingStatus.equals("Booked")) {
            waitingList.remove(0);
        } else if (waitingList.size() > 1 && waitingList.get(1).bookingStatus.equals("Booked")) {
            waitingList.remove(1);
        }
        if (waitingList.size() > 0 && waitingList.get(0).bookingStatus.equals("Booked")) {
            waitingList.remove(0);
        }
        Train.currentWLAvail = waitingList.size();
    }

    // no params
    public void check() {
        train.printChart();
    }
}