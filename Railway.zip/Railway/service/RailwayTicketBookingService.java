package Railway.service;

public interface RailwayTicketBookingService {
    void execute();
}
