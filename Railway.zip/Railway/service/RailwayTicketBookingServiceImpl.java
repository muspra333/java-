package Railway.service;

import java.util.Scanner;

public class RailwayTicketBookingServiceImpl implements RailwayTicketBookingService {

    public void execute() {
        Booking booking = new Booking();
        Scanner scan = new Scanner(System.in);
        boolean isTrue = true;
        System.out.println(
                "For booking enter: book,src,dest,nooftickets \n For Cancel ticket enter: cancel,pnr,noofticket \n For summary & chart enter: check \n For exit type: exit \n");
        while (isTrue) {
            String choice = scan.nextLine();
            String[] s = choice.split(",");
            String service = s[0].toLowerCase();
            switch (service) {
                case "book":
                    booking.book(s, null);
                    break;
                case "cancel":
                    booking.cancel(s);
                    break;
                case "check":
                    booking.check();
                    break;
                case "exit":
                    isTrue = false;
                    break;
                default:
                    System.out.println("Invalid Input");
                    break;
            }
        }
    }
}
